import express from 'express';
import { deleteLaporan, getLaporan, getLaporanById, savepeLaporan, updateLaporan } from '../controller/Pelapor.js';
import { deleteEdukasi, getEdukasi, getEdukasiById, saveEdukasi, updateEdukasi } from '../controller/Edukasi.js';
import { deleteFeedback, getFeedback, getFeedbackById, saveFeedback, updateFeedback } from '../controller/Feedback.js';
import { refreshToken } from '../controller/RefreshToken.js';
import { getAllUsersWithMessages, getUsers, Login, Logout, Me, Register, updateDataUsers, updatePassword, updateProfileUsers, updateRoomForUser } from '../controller/Users.js';
import { verifyToken } from '../middleware/VerifyToken.js';
import { getmessage } from '../controller/Message.js';

const router = express.Router();

router.get('/users', getUsers);
router.post('/register', Register);
router.post('/login', Login);
router.get('/me', Me);
router.delete('/logout', Logout);
router.get('/token', refreshToken)
router.patch('/updateusers', updateDataUsers)
router.post('/updateprofile', updateProfileUsers)
router.post('/updatepassword', updatePassword)

router.get('/getmessage', getmessage)
router.patch('/updateroom', updateRoomForUser)
router.get('/getusersmessage', getAllUsersWithMessages)

router.get('/feedback', getFeedback);
router.get('/feedbackId/:id', getFeedbackById);
router.post('/saveFeed',verifyToken, saveFeedback);
router.patch('/updateFeed/:id', verifyToken, updateFeedback);
router.delete('/deleteFeed/:id',verifyToken, deleteFeedback);

router.get('/lapor', getLaporan);
router.get('/laporId/:id', getLaporanById);
router.post('/savelapor',verifyToken, savepeLaporan);
router.patch('/updatelapor/:id', verifyToken, updateLaporan);
router.delete('/deletelapor/:id',verifyToken, deleteLaporan);

router.get('/edukasi', getEdukasi);
router.get('/edukasiid/:id', getEdukasiById);
router.post('/saveedukasi',verifyToken, saveEdukasi);
router.patch('/updateedukasi/:id', verifyToken, updateEdukasi);
router.delete('/deleteedukasi/:id',verifyToken, deleteEdukasi);


export default router;
