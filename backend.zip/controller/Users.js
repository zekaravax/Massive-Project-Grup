import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import db from '../database/Database.js';
import path from 'path';

export const getUsers = async (req, res) => {
  try {
    const [rows, fields] = await db.query('SELECT * FROM tbl_users');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

export const Register = async (req, res) => {
  const { name, username, email, no_telp, password, confirmPassword } = req.body;
  if (password !== confirmPassword) {
    return res.status(400).json({
      msg: 'Password dan Confirm Password Tidak Cocok',
    });
  }

  const [user] = await db.query('SELECT * FROM tbl_users WHERE username = ?', [username]);
  if (user.length > 0) {
    return res.status(404).json({ msg: 'Username sudah ada! Ganti username!' });
  }

  const salt = await bcrypt.genSalt();
  const hashPassword = await bcrypt.hash(password, salt);
  const roomCode = `room-${Math.floor(new Date().getTime() / 1000)}`;

  try {
    await db.query('INSERT INTO tbl_users (name, username, email, no_telp, password, room) VALUES (?, ?, ?, ?, ?, ?)', [
      name,
      username,
      email,
      no_telp,
      hashPassword,
      roomCode
    ]);
    res.json({ msg: 'Register Berhasil' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

export const Login = async (req, res) => {
  try {
    const [user] = await db.query('SELECT * FROM tbl_users WHERE username = ?', [req.body.username]);

    if (user.length === 0) {
      return res.status(404).json({ msg: 'User not found' });
    }

    const match = await bcrypt.compare(req.body.password, user[0].password);
    if (!match) {
      return res.status(400).json({ msg: 'Wrong Password' });
    }

    const userId = user[0].id;
    const name = user[0].name;
    const username = user[0].username;
    const email = user[0].email;
    const no_telp = user[0].no_telp;
    const alamat = user[0].alamat
    const image = user[0].image
    const nik = user[0].nik
    const jk = user[0].jk
    const tgl = user[0].tanggal_lahir
    const role = user[0].role

    const accessToken = jwt.sign(
      { userId, name, username, email, no_telp, alamat, image, nik, jk, tgl, role },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: '1d' }
    );
    const refreshToken = jwt.sign(
      { userId, name, username, email, no_telp, alamat, image, nik, jk, tgl, role },
      process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: '1d' }
    );

    await db.query('UPDATE tbl_users SET refresh_token = ? WHERE id = ?', [refreshToken, userId]);

    res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000
        // secure: true ## for https
    })

    res.json({ accessToken, role });
  } catch (error) {
    console.error(error);
    return res.status(401).json({ msg: error.message });
  }
};

export const Me = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(204);
    const [user] = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!user[0]) {
      return res.sendStatus(204);
    }

    const [response] = await db.query('SELECT * FROM tbl_users WHERE id = ?', [user[0].id]);
    res.json(response[0]);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

export const Logout = async (req, res) => {
  const refreshToken = req.cookies.refreshToken;
  if (!refreshToken) return res.status(204);
  const [user] = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

  if (!user[0]) {
    return res.sendStatus(204);
  }

  const userId = user[0].id;

  await db.query('UPDATE tbl_users SET refresh_token = NULL WHERE id = ?', [userId]);
  res.clearCookie('refreshToken');
  return res.sendStatus(200);
};


export const updateDataUsers = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(204).json({ msg: 'No Refresh Token provided' });

    const users = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!users[0][0]) {
      return res.status(204).json({ msg: 'User not found' });
    }

    const userId = users[0][0].id; 
    const name = req.body.name;
    const email = req.body.email;
    const jk = req.body.jk;
    const no_telp = req.body.no_telp;
    const bio = req.body.bio;

    try {
      await db.query('UPDATE tbl_users SET name = ?, email = ?, jk = ?, no_telp = ?, bio = ? WHERE id = ?', [
        name,
        email,
        jk,
        no_telp,
        bio,
        userId
      ]);

      res.status(200).json({
        msg: 'User data has been updated',
      });
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: 'Internal Server Error' });
    }
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ msg: 'Internal Server Error' });
  }
};

export const updateProfileUsers = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(204).json({ msg: 'No Refresh Token provided' });

    const users = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!users[0][0]) {
      return res.status(204).json({ msg: 'User not found' });
    }

    const userId = users[0][0].id;
    let fileName = users[0][0].image;

    if (req.files !== null) {
      const file = req.files.file;
      const fileSize = file.data.length;
      const ext = path.extname(file.name);
      fileName = file.md5 + ext;
      const allowedTypes = ['.png', '.jpg', '.jpeg'];

      if (!allowedTypes.includes(ext.toLowerCase())) {
        return res.status(422).json({ msg: 'Invalid Image' });
      }

      if (fileSize > 8000000) {
        return res.status(422).json({ msg: 'Max Image Size 8MB' });
      }

      file.mv(`./public/profile/${fileName}`, (err) => {
        if (err) {
          return res.status(500).json({ msg: err.message });
        }
      });
    }

    const url = `${req.protocol}://${req.get('host')}/profile/${fileName}`;

    try {
      await db.query('UPDATE tbl_users SET url = ?, image = ? WHERE id = ?', [
        url,
        fileName,
        userId
      ]);

      res.status(200).json({
        msg: 'User profile updated',
      });
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: 'Internal Server Error' });
    }
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ msg: 'Internal Server Error' });
  }
};


// Backend (Node.js / Express)
export const updatePassword = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(204);

    const users = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!users[0][0]) {
      return res.status(204).json({
        msg: 'User Tidak Ditemukan',
      });
    }

    const userId = users[0][0].id; 
    const currentPassword = req.body.currentPassword;
    const newPassword = req.body.newPassword;
    const confirmPassword = req.body.confirmPassword;

    // Pengecekan password sebelumnya
    const isPasswordCorrect = await bcrypt.compare(currentPassword, users[0][0].password);
    if (!isPasswordCorrect) {
      return res.status(400).json({
        msg: 'Password Sebelumnya Salah',
      });
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({
        msg: 'Password dan Confirm Password Tidak Cocok',
      });
    }

    try {
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await db.query('UPDATE tbl_users SET password = ? WHERE id = ?', [
        hashedPassword,
        userId
      ]);

      res.status(200).json({
        msg: 'Data Users Telah Diupdate',
      });
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: 'Internal Server Error' });
    }
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ msg: 'Internal Server Error' });
  }
};

export const updateRoomForUser = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(204).json({ msg: 'No Refresh Token provided' });

    const users = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!users[0][0]) {
      return res.status(204).json({ msg: 'User not found' });
    }

    const userId = users[0][0].id;
    const role = users[0][0].role; 

    if (role === 'guru') {
      const room = req.body.room;

      try {
        await db.query('UPDATE tbl_users SET room = ? WHERE id = ?', [room, userId]);

        res.status(200).json({
          msg: 'User room has been updated',
        });
      } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Internal Server Error' });
      }
    } else {
      res.status(403).json({ msg: 'Forbidden: Only guru can update room' });
    }
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ msg: 'Internal Server Error' });
  }
};

export const getAllUsersWithMessages = async (req, res) => {
  try {
    const query = `
      SELECT u.*
      FROM tbl_users u
      WHERE EXISTS (
        SELECT 1
        FROM messages m
        WHERE m.user_id = u.id
      ) AND u.role != 'guru';
    `;

    const result = await db.query(query);
    res.json(result[0]);
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

