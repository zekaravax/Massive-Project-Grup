import db from '../database/Database.js';

export const getmessage =  async (req, res) => {
    const refreshToken = req.cookies.refreshToken;

    if (!refreshToken) {
      return res.status(204).json({}); 
    }

    const [user] = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!user[0]) {
      return res.status(204).json({});
    }

    const room = user[0].room; 
    try {
      const result = await db.query(
        'SELECT * FROM messages WHERE room = ? ORDER BY time ASC',
        [room]
      );
  
      res.json(result[0]);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ error: 'Internal Server Error', data: error });
    }
};
