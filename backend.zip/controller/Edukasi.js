import db from '../database/Database.js';
import path from 'path';
import fs from 'fs';

export const getEdukasi = async (req, res) => {
  try {
    const response = await db.query('SELECT * FROM tbl_edukasi');
    res.json(response[0]);
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ msg: 'Internal Server Error' });
  }
};

export const getEdukasiById = async (req, res) => {
  try {
    const Edukasi = await db.query(
      'SELECT * FROM tbl_edukasi WHERE id = ?',
      [req.params.id]
    );
    res.json(Edukasi[0][0]); 
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ msg: 'Internal Server Error' });
  }
};

export const saveEdukasi = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(204);

    const users = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!users[0][0]) {
      return res.status(204).json({
        msg: 'User Tidak Ditemukan',
      });
    }

    const userId = users[0][0].id; 

    if (req.files === null) return res.status(400).json({ msg: 'Tidak Ada File yang Diupload' });
    
    const judul = req.body.judul;
    const content = req.body.content;
    const file = req.files.file;
    const fileSize = file.data.length;
    const ext = path.extname(file.name);
    const fileName = file.md5 + ext;
    const url = `${req.protocol}://${req.get('host')}/images/${fileName}`;
    const allowedType = ['.png', '.jpg', '.jpeg'];

    if (!allowedType.includes(ext.toLowerCase())) {
      return res.status(422).json({ msg: 'Gambar Invalid' });
    }

    if (fileSize > 8000000) {
      return res.status(422).json({ msg: 'Max Image Sized 8MB' });
    }

    file.mv(`./public/images/${fileName}`, async (err) => {
      if (err) {
        return res.status(500).json({ msg: err.message });
      }

      try {
        await db.query('INSERT INTO tbl_edukasi (id_users, judul,content, image, url) VALUES (?,?,?, ?, ?)', [userId, judul,content, fileName, url]);
        res.status(201).json({ msg: 'Edukasi Berhasil Dibuat' });
      } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Internal Server Error dalam', error: error.message });
      }
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ msg: 'Internal Server Error luar', error: error.message });
  }
};

  export const updateEdukasi = async (req, res) => {
    try {
      const refreshToken = req.cookies.refreshToken;
      if (!refreshToken) return res.status(204);

      const users = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

      if (!users[0][0]) {
        return res.status(204).json({
          msg: 'User Tidak Ditemukan',
        });
      }

      
  
      const edukasi = await db.query('SELECT * FROM tbl_Edukasi WHERE id = ?', [req.params.id]);
  
      if (!edukasi[0][0]) {
        res.status(404).json({ msg: 'Data Tidak Ditemukan' });
      }
  
      let fileName = edukasi[0][0].image;

        if (req.files !== null) {
        const file = req.files.file;
        const fileSize = file.data.length;
        const ext = path.extname(file.name);
        fileName = file.md5 + ext;
        const allowedType = ['.png', '.jpg', '.jpeg'];

        if (!allowedType.includes(ext.toLowerCase())) {
            return res.status(422).json({ msg: 'Gambar Invalid' });
        }
        if (fileSize > 8000000) {
            return res.status(422).json({ msg: 'Max Image Sized 8MB' });
        }

        if (edukasi[0][0].image) {
            const filePath = `./public/images/${edukasi[0][0].image}`;
            fs.unlinkSync(filePath);
        }

        file.mv(`./public/images/${fileName}`, (err) => {
            if (err) {
            return res.status(500).json({ msg: err.message });
            }
        });
        }
  
      const userId = users[0][0].id; 
      const judul = req.body.judul;
      const content = req.body.content;
      const url = `${req.protocol}://${req.get('host')}/images/${fileName}`;
  
      try {
        await db.query('UPDATE tbl_edukasi SET id_users = ?,judul = ?, content = ?, url = ?, image = ? WHERE id = ?', [
          userId,
          judul,
          content,
          url,
          fileName,
          req.params.id,
        ]);
        res.status(200).json({
          msg: 'Edukasi Telah Diupdate',
        });
      } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Internal Server Error' });
      }
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: 'Internal Server Error' });
    }
  };
  

  export const deleteEdukasi = async (req, res) => {
    try {
      const refreshToken = req.cookies.refreshToken;
      if (!refreshToken) return res.status(204).json({ msg: 'Tidak Mempunyai Akses' });
  
      const users = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

      if (!users[0][0]) {
        return res.status(204).json({
          msg: 'User Tidak Ditemukan',
        });
      }
  
      const edukasi = await db.query('SELECT * FROM tbl_edukasi WHERE id = ?', [req.params.id]);
  
      if (!edukasi[0][0]) {
        res.status(404).json({ msg: 'Data Tidak Ditemukan' });
      }
  
      try {
        if (edukasi[0][0].image) {
          const filePath = `./public/images/${edukasi[0][0].image}`;
          fs.unlinkSync(filePath);
        }
        await db.query('DELETE FROM tbl_edukasi WHERE id = ?', [req.params.id]);
        res.status(200).json({
          msg: 'Edukasi Berhasil Dihapus',
        });
      } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Internal Server Error' });
      }
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: 'Internal Server Error' });
    }
  };
  