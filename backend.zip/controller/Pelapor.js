import db from '../database/Database.js';
import path from 'path';
import fs from 'fs';

export const getLaporan = async (req, res) => {
  try {
    const response = await db.query(`
      SELECT * FROM tbl_pelapor
    `);
    res.json(response[0]);
  } catch (error) {
    console.log(error.message);
    res.status(401).json({
      msg: error.message,
    });
  }
};

export const getLaporanById = async (req, res) => {
  try {
    const response = await db.query(`
    SELECT * FROM tbl_pelapor
      WHERE id = ?
    `, [req.params.id]);
    res.json(response[0][0]);
  } catch (error) {
    console.log(error.message);
    res.status(401).json({
      msg: error.message,
    });
  }
};

export const savepeLaporan = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(204);

    const user = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!user[0][0]) {
      return res.status(204).json({
        msg: 'User Tidak Ditemukan',
      });
    }

    if (req.files === null) return res.status(400).json({ msg: 'Tidak Ada File yang Diupload' });
    const userId = user[0][0].id; 
    const name = req.body.name;
    const jenkel = req.body.jenkel;
    const email = req.body.email;
    const no_hp = req.body.no_hp;
    const kelas = req.body.kelas;
    const jurusan = req.body.jurusan;
    const judul_laporan = req.body.judul_laporan;
    const isi_laporan = req.body.isi_laporan;
    const tanggal_kejadian = req.body.tanggal_kejadian;
    const file = req.files.file;
    const fileSize = file.data.length;
    const ext = path.extname(file.name);
    const fileName = file.md5 + ext;
    const url = `${req.protocol}://${req.get('host')}/pelaporan/${fileName}`;
    const allowedType = ['.png', '.jpg', '.jpeg'];

    if (!allowedType.includes(ext.toLowerCase())) {
      return res.status(422).json({ msg: 'Gambar Invalid' });
    }

    if (fileSize > 8000000) {
      return res.status(422).json({ msg: 'Max Image Sized 8MB' });
    }

    file.mv(`./public/pelaporan/${fileName}`, async (err) => {
      if (err) {
        return res.status(500).json({ msg: err.message });
      }

      try {
        await db.query('INSERT INTO tbl_pelapor (id_users, name, jenkel, email, no_hp, kelas, jurusan, judul_laporan, isi_laporan,tanggal_kejadian, image, url) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', [userId, name, jenkel, email, no_hp, kelas, jurusan, judul_laporan, isi_laporan,tanggal_kejadian, fileName, url]);

        res.status(201).json({ msg: 'Laporan Berhasil Dibuat' });
      } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Internal Server Error dalam', error: error.message });
      }
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ msg: 'Internal Server Error luar', error: error.message });
  }
};

export const updateLaporan = async (req, res) => {
    try {
      const refreshToken = req.cookies.refreshToken;
      if (!refreshToken) return res.status(204).json({ msg: 'Refresh token is required' });
  
      const user = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);
  
      if (!user[0][0]) {
        return res.status(204).json({
          msg: 'User Tidak Ditemukan',
        });
      }
  
      const Laporan = await db.query('SELECT * FROM tbl_pelapor WHERE id = ?', [req.params.id]);
  
      if (!Laporan[0][0]) {
        res.status(404).json({ msg: 'Data Tidak Ditemukan' });
      }
  
      let fileName = Laporan[0][0].image;

        if (req.files !== null) {
        const file = req.files.file;
        const fileSize = file.data.length;
        const ext = path.extname(file.name);
        fileName = file.md5 + ext;
        const allowedType = ['.png', '.jpg', '.jpeg'];

        if (!allowedType.includes(ext.toLowerCase())) {
            return res.status(422).json({ msg: 'Gambar Invalid' });
        }
        if (fileSize > 8000000) {
            return res.status(422).json({ msg: 'Max Image Sized 8MB' });
        }

        if (Laporan[0][0].image) {
            const filePath = `./public/pelaporan/${Laporan[0][0].image}`;
            fs.unlinkSync(filePath);
        }

        file.mv(`./public/pelaporan/${fileName}`, (err) => {
            if (err) {
            return res.status(500).json({ msg: err.message });
            }
        });
        }
  
        const userId = user[0][0].id; 
        const name = req.body.name;
        const jenkel = req.body.jenkel;
        const email = req.body.email;
        const no_hp = req.body.no_hp;
        const kelas = req.body.kelas;
        const jurusan = req.body.jurusan;
        const judul_laporan = req.body.judul_laporan;
        const isi_laporan = req.body.isi_laporan;
        const tanggal_kejadian = req.body.tanggal_kejadian;

      const url = `${req.protocol}://${req.get('host')}/pelaporan/${fileName}`;
  
      try {
        await db.query('UPDATE tbl_pelapor SET id_users = ?,name = ?, jenkel = ?, email = ?, no_hp = ?, kelas =?, jurusan = ?, judul_laporan = ?, isi_laporan = ?,tanggal_kejadian = ?, url = ?, image = ? WHERE id = ?', [
          userId,
          name,
          jenkel,
          email,
          no_hp,
          kelas,
          jurusan,
          judul_laporan,
          isi_laporan,
          tanggal_kejadian,
          url,
          fileName,
          req.params.id,
        ]);
        res.status(200).json({
          msg: 'Laporan Telah Diupdate',
        });
      } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Internal Server Error' });
      }
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: 'Internal Server Error' });
    }
  };

export const deleteLaporan = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(204);

    const user = await db.query('SELECT * FROM tbl_users WHERE refresh_token = ?', [refreshToken]);

    if (!user[0][0]) {
      return res.status(204).json({
        msg: 'User Tidak Ditemukan',
      });
    }

    const laporan = await db.query('SELECT * FROM tbl_pelapor WHERE id = ?', [req.params.id]);

  
      if (!laporan[0][0]) {
        res.status(404).json({ msg: 'Data Tidak Ditemukan' });
      }
  
      try {
        if (laporan[0][0].image) {
          const filePath = `./public/pelaporan/${laporan[0][0].image}`;
          fs.unlinkSync(filePath);
        }
        await db.query('DELETE FROM tbl_edukasi WHERE id = ?', [req.params.id]);
        res.status(200).json({
          msg: 'Laporan Berhasil Dihapus',
        });
      } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Internal Server Error' });
      }
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: 'Internal Server Error' });
    }
};
