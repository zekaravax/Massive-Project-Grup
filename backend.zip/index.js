import express from 'express';
import cookieParser from 'cookie-parser';
import fileUpload from 'express-fileupload';
import cors from 'cors';
import dotenv from 'dotenv';
import db from './database/Database.js';
import router from './routes/index.js';
import { Server } from 'socket.io'; 
import http from 'http'; 
dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

const roomMessages = {}; 
const pool = db;

const getConnection = async () => {
  return await pool.getConnection();
};

const start = async function () {
  try {
    console.log('Database Connected');
  } catch (e) {
    console.log(e);
  }
};

app.use(cors({ credentials: true, origin: 'http://localhost:5173' }));
app.use(cookieParser());
app.use(express.json());
app.use(fileUpload());
app.use(express.static('public'));

app.options('*', cors());

app.use(async (req, res, next) => {
  let connection;
  try {
    connection = await getConnection();
    req.db = connection;
    next();
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    if (connection) {
      connection.release();
    }
  }
});

app.use(router);

start();

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: 'http://localhost:5173',
    methods: ['GET', 'POST'],
  },
});

io.on("connection", (socket) => {
  console.log(`User Connected: ${socket.id}`);

  socket.on("join_room", async (data) => {
    socket.join(data);
    console.log(`User with ID: ${socket.id} joined room: ${data}`);

    if (roomMessages[data]) {
      socket.emit("load_messages", roomMessages[data]);
    }
  });

  socket.on("send_message", async (data) => {
    // Simpan pesan ke database
    const { user_id, room, author, message, time } = data;
    const insertQuery = `INSERT INTO messages (user_id, room, author, message, time) VALUES (?, ?, ?, ?, ?)`;
    

    try {
      const result = await pool.query(insertQuery, [user_id, room, author, message, time]);
      console.log("Message saved to database:", result);
    } catch (error) {
      console.error("Error saving message to database:", error);
    }

    if (!roomMessages[data.room]) {
      roomMessages[data.room] = [];
    }
    roomMessages[data.room].push(data);

    // Kirim pesan ke semua pengguna di ruangan
    io.to(data.room).emit("receive_message", data);
    console.log(data);
  });

  socket.on("disconnect", () => {
    console.log("User Disconnected", socket.id);
  });
});

server.listen(port, () => {
  console.log(`Server berjalan di port ${port}`);
});
