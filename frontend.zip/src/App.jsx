import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './App.css'
import ChatPage from './pages/Chat'
import Edukasi from './pages/Edukasi'
import Konsultasi from './pages/Konsultasi'
import Home from './pages/LandingPage'
import Login from './pages/Login'
import MainSample from './pages/mainsample'
import Pelaporan from './pages/Pelaporan'
import Register from './pages/Register'
import ChatBox from './pages/sample'
import TeacherChatBox from './pages/sampleguru'
import Users from './pages/Users'

function App() {

  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/edukasi" element={<Edukasi />} />
          <Route path="/pelaporan" element={<Pelaporan />} />
          <Route path="/konsultasi" element={<Konsultasi />} />
          <Route path="/chatpage" element={<ChatPage />} />
          <Route path="/users" element={<Users />} />
          <Route path="/socket" element={<MainSample />} />
          <Route path="/sampleg" element={<TeacherChatBox />} />
          <Route path="/sample" element={<ChatBox />} />
        </Routes>
      </Router>
    </>
  )
}

export default App
