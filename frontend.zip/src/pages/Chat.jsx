import React, { useState, useRef, useEffect } from "react";
import { Container, Row, Col, Form, Button } from "react-bootstrap";
import { BsArrowRightShort } from "react-icons/bs";
import Footer from "../components/Footer";
import Headers from "../components/Headers";
import defaultProfileImage from "../assets/woman.png"; // Add the path to your default profile image

const red = '#BB2525';

const ChatPage = () => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");

  const messagesEndRef = useRef(null);

  useEffect(() => {
    // Scroll to the bottom of the messages when component mounts or messages change
    messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (newMessage.trim() === "") return;

    const newMessages = [...messages, { text: newMessage, sender: "user" }];
    setMessages(newMessages);
    setNewMessage("");
  };

  return (
    <div className="overflow-x-hidden">
      <Headers title="John Doe" profileImage={defaultProfileImage} />
      <Container>
        <Row className="mt-5 mb-5">
          <Col md={8} className="text-white p-4 ml-auto" style={{ background: `url(${defaultProfileImage}) center/cover`, boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)', borderRadius: '15px' }}>
            <div style={{ height: "400px", overflowY: "auto", marginBottom: "20px" }}>
              {messages.map((message, index) => (
                <div key={index} className={message.sender === "admin" ? "admin-message" : "user-message"}>
                  <p>{message.text}</p>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            <Form className="mb-3">
              <Form.Group className="d-flex">
                <Form.Control
                  type="text"
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                />
                <Button type="button" onClick={handleSendMessage} className="ml-2">
                  <BsArrowRightShort />
                </Button>
              </Form.Group>
            </Form>
          </Col>
        </Row>
      </Container>
      <Footer style={{ background: red, textAlign: "center" }} />
    </div>
  );
};

export default ChatPage;
