
import axios from 'axios';
import { useState, useEffect } from 'react';
import { Button, Card, FormControl } from 'react-bootstrap';
import ScrollToBottom from 'react-scroll-to-bottom';
import useTokenRefresh from '../controllers/useToken';

const ChatBox = ({ socket, username, room, userId }) => {
  const [currentMessage, setCurrentMessage] = useState("");
  const [messageList, setMessageList] = useState([]);
  const { refreshToken } = useTokenRefresh()

  useEffect(() => {
    refreshToken();
    getmessage();
  }, [])

  const getmessage = async () => {
    try {
      const response = await axios.get(`http://localhost:3000/getmessage`);
      const newMessages = response.data.filter((message) => !messageList.some((existing) => existing.id === message.id));
      setMessageList((list) => [...list, ...newMessages]);
      console.log("Data Response:", response.data);
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const sendMessage = async () => {
    if (currentMessage !== "") {
      const messageData = {
        user_id: userId,
        room: room,
        author: username,
        message: currentMessage,
        time:
          new Date(Date.now()).getHours() +
          ":" +
          new Date(Date.now()).getMinutes(),
      };
  
      await socket.emit("send_message", messageData);
      setMessageList((list) => [...list, messageData]);
      setCurrentMessage("");
    }
  };
  


  useEffect(() => {
    socket.on("receive_message", (data) => {
      setMessageList((list) => {
        const isMessageAlreadyExists = list.some(item => item.id === data.id);
  
        if (!isMessageAlreadyExists) {
          // Merging data baru dengan data sebelumnya tanpa membuat array baru
          return [...list, data];
        } else {
          // Jika pesan sudah ada, kembalikan list tanpa perubahan
          return list;
        }
      });
    });
  }, []);

  return (
    <Card style={{ margin: '20px', borderRadius: '15px', overflow: 'hidden', boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)' }}>
      <Card.Header style={{ backgroundColor: '#3498db', color: '#fff', padding: '20px' }}>
        <Card.Title>Live Chat</Card.Title>
      </Card.Header>
      <Card.Body className='chat-body' style={{ maxHeight: '300px', overflowY: 'auto', display: 'flex', flexDirection: 'column-reverse' }}>
        <ScrollToBottom>
          {messageList.map((messageContent) => {
            const isCurrentUser = username === messageContent.author;
            const messageStyle = {
              alignSelf: isCurrentUser ? 'flex-end' : 'flex-start', // Switched alignSelf values
              backgroundColor: isCurrentUser ? '#2ecc71' : '#3498db',
              color: isCurrentUser ? '#fff' : '#000',
              borderRadius: isCurrentUser ? '15px 15px 0 15px' : '15px 15px 15px 0', // Adjusted borderRadius values
              marginLeft: isCurrentUser ? '35rem' : '10px', // Switched marginLeft and marginRight values
              marginRight: isCurrentUser ? '10px' : '35rem', // Switched marginLeft and marginRight values
              marginBottom: '10px',
              padding: '10px',
              maxWidth: '100%', // Adjust as needed
            };

            return (
              <div key={messageContent.id}  style={messageStyle}>
                <div>
                  <div>
                    <p>{messageContent.message}</p>
                  </div>
                  <div >
                    <p id="time" style={{ fontSize: "10px" }}>{messageContent.time}</p>
                    <p id="author" style={{ fontWeight: "bold", fontSize: "10px"}}>{messageContent.author}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </ScrollToBottom>
      </Card.Body>


        <Card.Footer style={{ display: 'flex', alignItems: 'center' }}>
          <FormControl
            type="text"
            value={currentMessage}
            placeholder="Hey..."
            onChange={(event) => {
              setCurrentMessage(event.target.value);
            }}
            style={{ flex: '1', borderRadius: '5px 0 0 5px' }}
          />
          <Button variant="success" style={{ borderRadius: '0 5px 5px 0' }} onClick={sendMessage}>
            &#9658;
          </Button>
        </Card.Footer>

      </Card>
  );
}

export default ChatBox;
