import { Card, Col, Container, Image, Row } from "react-bootstrap";
import Footer from "../components/Footer";
import Headers from "../components/Headers";
import BreadcumbContentEdukasi from "../components/BreadcumbEdukasi";
import breadcumbImg from '../assets/edukasi.png';
import FloatingButton from "../components/FloatingButton";
import { useEffect, useState } from "react";
import useTokenRefresh from "../controllers/useToken";
import { EdukasiAllData } from "../controllers/EdukasiData";
import PopupFormEdukasi from "../components/PopupForm";

const red = '#BB2525';

const Edukasi = () => {
  const { data, refreshToken } = useTokenRefresh();
  const { edukasi } = EdukasiAllData(); 
  const [isPopupVisible, setPopupVisible] = useState(false);

  useEffect(() => {
    refreshToken();
  }, []);

  const handleFloatingButtonClick = () => {
    setPopupVisible(true); 
  };

  const handleClosePopup = () => {
    setPopupVisible(false); 
  };

  return (
    <div className="overflow-x-hidden">
      <Headers />
      <BreadcumbContentEdukasi image={breadcumbImg} title="Edukasi" sub2="Inilah beberapa artikel akurat dan terpercaya yang akan mengedukasi pembaca tentang kekerasan di sekolah" />
      <Container className="my-5">
        <Row className={`mt-5 p-4 ${edukasi.length > 3 ? 'flex-wrap' : 'justify-content-center'}`}>
          {edukasi.map((card, index) => (
            <Col key={index} xs={12} md={4}>
              <Card style={{ marginBottom: '15px', borderRadius: '15px' }}>
                <Card.Header>
                  <Image src={card.url} style={{ width: '100%', objectFit: 'cover' }} />
                </Card.Header>
                <Card.Title className="mb-0" style={{ backgroundColor: red, color: 'white', padding: '5px' }}>
                  {card.judul}
                </Card.Title>
                <div className="border-top border-white"></div>
                <Card.Body style={{ backgroundColor: red, color: 'white' }}>
                  <p>{card.content}</p>
                </Card.Body>
                <Card.Footer style={{ backgroundColor: red, color: 'white', display: 'flex', justifyContent: 'flex-end' }}>
                  <small className="text-white">
                    <a href="#">Baca Lebih Lanjut</a>
                  </small>
                </Card.Footer>
              </Card>
            </Col>
          ))}
        </Row>
        {data.role === 'guru' && (
          <div className="text-end">
            <FloatingButton onClick={handleFloatingButtonClick} />
          </div>
        )}
        <PopupFormEdukasi isVisible={isPopupVisible} onClose={handleClosePopup} />

      </Container>
      <Footer />
    </div>
  );
};

export default Edukasi;