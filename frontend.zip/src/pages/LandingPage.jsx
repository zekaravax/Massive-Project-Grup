import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import BreadcumbContent from "../components/Breadcumb";
import Footer from "../components/Footer";
import Headers from "../components/Headers";
import { faInfo, faNewspaper, faComputer, faEnvelope, faPhone } from "@fortawesome/free-solid-svg-icons";
import { faFacebook, faTwitter, faInstagram, faYoutube } from "@fortawesome/free-brands-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";

const red = '#BB2525';
const boxShadow = '0px 0px 10px rgba(0, 0, 0, 0.4)';
const borderRadius = '15px';
const button = '#2B2A4C';
const Home = () => {
  return (
    <div className="overflow-x-hidden">
      <Headers />
      <BreadcumbContent />
      <Container className="my-5">

        <Row className="mt-5 p-4 justify-content-center" style={{ backgroundColor: "#BB2525", boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px' }}>
          <h2 className="text-center font-bold shadow-md" style={{ color: "#2B2A4C", textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}>Tentang Kami</h2>
          <p className="text-white">
          Kami membantu orang-orang melaporkan, mendokumentasikan, dan menangani kasus-kasus penindasan.

            Tujuan situs web ini adalah untuk memberikan dukungan kepada para korban, memfasilitasi pelaporan insiden pelanggaran, dan mendorong tindakan atau intervensi penegakan keadilan yang diperlukan.
          </p>
        </Row>

        <Row className="mt-5 p-4 justify-content-center" style={{ boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px' }}>
          <h2 className="text-center font-bold shadow-md" style={{ color: "#2B2A4C", textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}>Layanan Kami</h2>
                  <Col className="text-center">
                <Link to={'/edukasi'}>
                    <Card style={{ marginBottom: '15px', borderRadius: '15px' }}>
                      <Card.Title>
                        <FontAwesomeIcon icon={faInfo} size="3x" style={{ color: "#2B2A4C" }} />
                      </Card.Title>
                      <Card.Body style={{ backgroundColor: "#2B2A4C", color: "white" }}>
                        <h3>Edukasi</h3>
                        {/* Additional information */}
                      </Card.Body>
                    </Card>
                </Link>
                  </Col>
                  <Col className="text-center">
                <Link to={'/pelaporan'}>
                    <Card style={{ marginBottom: '15px', borderRadius: '15px' }}>
                      <Card.Title>
                        <FontAwesomeIcon icon={faNewspaper} size="3x" style={{ color: "#2B2A4C" }} />
                      </Card.Title>
                      <Card.Body style={{ backgroundColor: "#2B2A4C", color: "white" }}>
                        <h3>Pelaporan</h3>
                        {/* Additional information */}
                      </Card.Body>
                    </Card>
                </Link>
                  </Col>
                  <Col className="text-center">
                <Link to={'/konsultasi'}>
                    <Card style={{ marginBottom: '15px', borderRadius: '15px' }}>
                      <Card.Title>
                        <FontAwesomeIcon icon={faComputer} size="3x" style={{ color: "#2B2A4C" }} />
                      </Card.Title>
                      <Card.Body style={{ backgroundColor: "#2B2A4C", color: "white" }}>
                        <h3>Konsultasi</h3>
                        {/* Additional information */}
                      </Card.Body>
                    </Card>
                </Link>
                  </Col>
        </Row>


        <Row className="mt-5 p-4 justify-content-center" style={{ boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px' }}>
          <h2 className="text-center font-bold shadow-md" style={{ color: "#2B2A4C", textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}>Petanyaan Yang Sering Ditanya</h2>
          <p className="text-white" style={{ backgroundColor: "#BB2525" }}>
            Bagaimana kita dapat melaporkan penindasan pada webite ini?
          </p>
          <p className="text-white" style={{ backgroundColor: "#BB2525" }}>
          Apakah situs web ini menawarkan dukungan psikologis atau bantuan konseling kepada korban penindasan?
        </p>
          <p className="text-white" style={{ backgroundColor: "#BB2525" }}>
          Apa yang harus di persiapkan untuk melaporkan insiden penindasan pada website ini?
                    </p>
          <p className="text-white" style={{ backgroundColor: "#BB2525" }}>
          Bagaimana proses pemantauan kasus penindasan melalui website ini?
       </p>
        </Row>

        <Row className="mt-5 bg-light p-4" style={{ boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)', borderRadius: '15px' }}>
          <h2 className="text-xl font-bold mb-4 mt-5 text-center" style={{ color: "#2B2A4C", textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}>Kontak</h2>
          <p className="text-center" style={{ color: "#2B2A4C" }}>Silahkan tinggalkan pesan dan kesan anda </p>
          <Col md={6}>
            <p className="mt-4 font-bold text-xl" style={{ color: "#C03D3E", fontWeight: "bold", fontSize: "1rem" }}>
              Hubungi Kami
            </p>
            <p style={{ color: "#2B2A4C" }}>
            Silahkan hubungi kami pada kontak dibawah ini
            </p>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FontAwesomeIcon icon={faEnvelope} size="1x"  style={{ backgroundColor: "#BB2525", padding: "1rem", color: "white",  boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px' }} />
              <Col style={{ marginLeft: '8px', color: "#2B2A4C" }}>
              <p >Email:</p>
              <p style={{ fontWeight: "bold" }}> abuseshield@gmail.com</p>
              </Col>
            </div>

            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FontAwesomeIcon icon={faPhone} size="1x"  style={{ backgroundColor: "#BB2525", padding: "1rem", color: "white",  boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px' }} />
              <Col style={{ marginLeft: '8px', color: "#2B2A4C" }}>
              <p >No. Telephone :</p>
              <p style={{ fontWeight: "bold" }}> +62 810 7743 6210</p>
              </Col>
            </div>
            <p style={{ color: "#BB2525" }}>
            Ikuti Kami di Media Sosial
            </p>

            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FontAwesomeIcon icon={faFacebook} size="1x"  style={{ backgroundColor: "#BB2525", padding: "1rem", color: "white",  boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px', marginLeft:"10px" }} />
              <FontAwesomeIcon icon={faTwitter} size="1x"  style={{ backgroundColor: "#BB2525", padding: "1rem", color: "white",  boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px', marginLeft:"10px" }} />
              <FontAwesomeIcon icon={faEnvelope} size="1x"  style={{ backgroundColor: "#BB2525", padding: "1rem", color: "white",  boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px', marginLeft:"10px" }} />
              <FontAwesomeIcon icon={faInstagram} size="1x"  style={{ backgroundColor: "#BB2525", padding: "1rem", color: "white",  boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px', marginLeft:"10px" }} />
              <FontAwesomeIcon icon={faYoutube} size="1x"  style={{ backgroundColor: "#BB2525", padding: "1rem", color: "white",  boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.4)', borderRadius: '15px', marginLeft:"10px" }} />
            </div>
          </Col>
          <Col md={6}>
          <div style={{ backgroundColor: red, padding: '20px', boxShadow: boxShadow, borderRadius: borderRadius }}>
            <Form className="text-white">
              <Row className="mb-3">
                <Form.Group as={Col} controlId="formNama">
                  <Form.Label>Nama</Form.Label>
                  <Form.Control type="text" placeholder="Masukkan Nama" />
                </Form.Group>
                <Form.Group as={Col} controlId="formEmail">
                  <Form.Label>Email</Form.Label>
                  <Form.Control type="email" placeholder="Masukkan Email" />
                </Form.Group>
              </Row>

              <Row className="mb-3">
                <Form.Group as={Col} controlId="formNoHp">
                  <Form.Label>No HP</Form.Label>
                  <Form.Control type="tel" placeholder="Masukkan No HP" />
                </Form.Group>
              </Row>

              <Row className="mb-3">
                <Form.Group as={Col} controlId="formPesan">
                  <Form.Label>Pesan</Form.Label>
                  <Form.Control as="textarea" rows={3} placeholder="Masukkan Pesan" />
                </Form.Group>
              </Row>

              <Button style={{ backgroundColor: button}} type="submit">
                Kirim Pesan
              </Button>
            </Form>
          </div>
          </Col>
        </Row>
      </Container>
      <Footer />
    </div>
  );
};

export default Home;
