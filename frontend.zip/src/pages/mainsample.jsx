// App.js

import ChatBox from "./sample";
import io from 'socket.io-client'
import { useEffect, useState } from "react";
import './css/sample.css'
import useTokenRefresh from "../controllers/useToken";
import axios from "axios";

const socket = io.connect("http://localhost:3000")

const MainSample = () => {
  const { refreshToken } = useTokenRefresh()
  
  const [username, setUsername] = useState("");
  const [userId, setUserId] = useState("");
  const [room, setRoom] = useState("");
  const [showChat, setShowChat] = useState(false);

  const joinRoom = () => {
    if (username !== "" && room !== "") {
      socket.emit("join_room", room);
      setShowChat(true);
    }
  };

  console.log(userId)

  const getMe = async() => {
    const response = await axios.get(`http://localhost:3000/me`)
    setUserId(response.data.id)
    setUsername(response.data.name)
    console.log("dataresp", response.data.name)
};
useEffect(() => {
  refreshToken();
  getMe();
}, [])

  return (
    <div className="App">
      {!showChat ? (
        <div className="joinChatContainer">
          <h3>Join A Chat</h3>
          <input
            type="text"
            placeholder="John..."
            value={username}
            onChange={(event) => {
              setUsername(event.target.value);
            }}
          />
          <input
            type="text"
            placeholder="Room ID..."
            onChange={(event) => {
              setRoom(event.target.value);
            }}
          />
          <button onClick={joinRoom}>Join A Room</button>
        </div>
      ) : (
        <ChatBox socket={socket} username={username} room={room} userId={userId} />
      )}
    </div>
  );
}
export default MainSample;
