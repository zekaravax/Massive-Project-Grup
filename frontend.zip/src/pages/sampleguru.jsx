// TeacherChatBox.js

import { useState, useEffect } from 'react';
import io from 'socket.io-client';
const socket = io('http://localhost:3000');

const TeacherChatBox = ({ teacherUserId }) => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    // Mendapatkan data pengguna dari server
    fetch('http://localhost:3000/usersdummy')
      .then((response) => response.json())
      .then((data) => setUsers(data));

    // Mengatur listener untuk pesan dari server
    socket.on('message', (data) => {
      setMessages((prevMessages) => [...prevMessages, data]);
    });

    return () => {
      // Membersihkan listener ketika komponen dilepas
      socket.off('message');
    };
  }, []);

  const sendMessage = () => {
    if (selectedUser && message) {
      const newMessage = {
        sender: 'guru1', // ID guru dummy
        receiver: selectedUser.id,
        text: message,
      };

      // Mengirim pesan ke server
      socket.emit('message', newMessage);

      // Menambahkan pesan ke daftar pesan
      setMessages((prevMessages) => [...prevMessages, newMessage]);

      // Mengosongkan pesan
      setMessage('');
    }
  };

  return (
    <div>
      <h1>Guru App</h1>
      <div>
        <h2>Users</h2>
        <ul>
          {users.map((user) => (
            <li key={user.id} onClick={() => setSelectedUser(user)}>
              {user.name} ({user.role})
            </li>
          ))}
        </ul>
      </div>
      {selectedUser && (
        <div>
          <h2>Chat with {selectedUser.name}</h2>
          <div style={{ border: '1px solid #ccc', padding: '10px', height: '200px', overflowY: 'auto' }}>
            {messages.map((msg, index) => (
              <div key={index}>
                {msg.sender}: {msg.text}
              </div>
            ))}
          </div>
          <div>
            <input type="text" value={message} onChange={(e) => setMessage(e.target.value)} />
            <button onClick={sendMessage}>Send</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeacherChatBox;
