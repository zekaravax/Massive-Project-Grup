import axios from "axios";
import { useEffect, useState } from "react";
import { Button, Col, Form, Row, Image } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import image from "../assets/Image.svg";

const red = '#BB2525';
const button = '#2B2A4C';

const Register = () => {

    const [name, setName] = useState('')
    const [username, setUsername] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const navigate = useNavigate()
    const [msg, setMsg] = useState('')
    const [showAlert, setShowAlert] = useState(false);


    const RegisterButton = async (e) => {
        e.preventDefault();
      
        if (!name || !email  || !username || !password || !confirmPassword) {
          setMsg('Please fill in all fields');

          return;
        } else {
      
            try {
            await axios.post('http://localhost:3000/register', {
                name: name,
                email: email,
                username: username,
                password: password,
                confirmPassword: confirmPassword,
            });
            navigate('/login');
            } catch (error) {
            setMsg(error.response.data.msg);
            }
        }
      };
      
      useEffect(() => {
        if (msg !== null && msg.trim() !== '') {
          setShowAlert(true);
        } else {
          setShowAlert(false);
        }
      }, [msg]);


  return (
    <div className="overflow-x-hidden" style={{ height: '100vh' }}>
      <div className="">
        <div className="">
          <Row style={{ background: red }}>
          <Col md={6}>
              <div style={{ backgroundColor: red, padding: '20px', marginTop: "3rem" }}>
                <h1 className="text-white" style={{ fontWeight: "bold" ,fontSize:"4rem",   marginLeft: "6rem"}}>Stop</h1>
                <h1 className="text-white" style={{ fontWeight: "bold", fontSize:"4rem", marginLeft: "8rem"}}>Bullying</h1>
                <h1 className="text-white">Daftar</h1>
                {showAlert && (
                  <div className="flex items-center bg-red-200 text-white text-sm font-bold px-4 py-3" role="alert">
                    <p>{msg}</p>
                  </div>
                )}
                <Form className="text-white">
                  <Row className="mb-3">
                    <Form.Group as={Col} controlId="formNama">
                      <Form.Label>Nama Lengkap</Form.Label>
                      <Form.Control type="text" placeholder="Masukkan Nama Lengkap" value={name} onChange={(e) => setName(e.target.value)} />
                    </Form.Group>
                  </Row>
                  <Row className="mb-3">
                    <Form.Group as={Col} controlId="formNama">
                      <Form.Label>Nama Pengguna</Form.Label>
                      <Form.Control type="text" placeholder="Masukkan Nama" value={username} onChange={(e) => setUsername(e.target.value)} />
                    </Form.Group>
                  </Row>
                  <Row className="mb-3">
                    <Form.Group as={Col} controlId="formNoHp">
                      <Form.Label>Email</Form.Label>
                      <Form.Control type="email" placeholder="Masukkan Email" value={email} onChange={(e) => setEmail(e.target.value)} />
                    </Form.Group>
                  </Row>
                  <Row className="mb-3">
                    <Form.Group as={Col} controlId="formNoHp">
                      <Form.Label>Kata Sandi</Form.Label>
                      <Form.Control type="password" placeholder="Masukkan Kata Sandi" value={password} onChange={(e) => setPassword(e.target.value)} />
                    </Form.Group>
                  </Row>
                  <Row className="mb-3">
                    <Form.Group as={Col} controlId="formNoHp">
                      <Form.Label>Konfirmasi Kata Sandi</Form.Label>
                      <Form.Control type="password" placeholder="Konfirmasi Kata Sandi" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
                    </Form.Group>
                  </Row>
                  <Button style={{ backgroundColor: button }} type="submit" className="w-100" onClick={RegisterButton}>
                    Daftar
                  </Button>
                  <p className="text-center">Sudah memiliki akun?
                  <Link to={'/login'}>
                  <span style={{ color: "#2B2A4C"}}>Login</span>
                  </Link>
                  </p>
                </Form>
              </div>
            </Col>
            <Col md={6}>
              <Image src={image} style={{ width: '100%', height: '100%', objectFit:"center" }} />
            </Col>
            
          </Row>
        </div>
      </div>
    </div>
  );
};

export default Register;
