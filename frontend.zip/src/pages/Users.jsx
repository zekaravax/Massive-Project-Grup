import React, { useEffect, useState } from "react";
import { Button, Col, Container, Form, Image, Modal, Row } from "react-bootstrap";
import Footer from "../components/Footer";
import Headers from "../components/Headers";
import useTokenRefresh from "../controllers/useToken";
import { UsersEditData, UsersReset } from "../controllers/UsersGetData"
import axios from "axios";
import { useNavigate } from "react-router-dom";
import defaultimg from '../assets/default.png'
const red = '#BB2525';
const boxShadow = '0px 0px 10px rgba(0, 0, 0, 0.4)';
const borderRadius = '15px';
const button = '#2B2A4C';

const Users = () => {
    const [isEditMode, setIsEditMode] = useState(true);
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [showPasswordModal, setShowPasswordModal] = useState(false);
    const { data, refreshToken, token } = useTokenRefresh()
    const { handlePassword, password,msg, handleSubmit, cpassword, handleCpassword, currentpassword, handleCurrentPassword } = UsersReset()
    const {
      imagePreview,
      handleImageChange,
      handleSubmitProfile
    } = UsersEditData()
    const [showAlert, setShowAlert] = useState(false);

    useEffect(() => {
      refreshToken();
    }, [refreshToken])

    useEffect(() => {
      if (msg !== null && msg.trim() !== '') {
        setShowAlert(true);
      } else {
        setShowAlert(false);
      }
    }, [msg]);

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [no_telp, setNoTelp] = useState('');
    const [bio, setBio] = useState('');
    const [jk, setJenisKelamin] = useState('');

    const handleJenisKelaminChange = (e) => {
      setJenisKelamin(e.target.id);
    };

    const handleSubmitData = async (e) => {
      e.preventDefault();

    try {
      const response = await axios.patch(`http://localhost:3000/updateusers`, {
        name,
        email,
        jk,
        no_telp,
        bio,
      }, {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
      });

      console.log("Success:", response);
      window.location.reload()
    } catch (error) {
      console.error("Error:", error);
    }
  };

    
    const handleEditClick = () => {
      setIsEditMode(true);
    };
  
    const handleSaveClick = () => {
      setIsEditMode(false);
    };
  
    const handleUploadClick = () => {
      setShowUploadModal(true);
    };
  
    const handlePasswordClick = () => {
      setShowPasswordModal(true);
    };
  
    const handleCloseUploadModal = () => {
      setShowUploadModal(false);
    };
  
    const handleClosePasswordModal = () => {
      setShowPasswordModal(false);
    };
  
  return (
    <div className="overflow-x-hidden">
      <Headers />
      <Container className="my-5">
        <Row className="mt-5 p-4" style={{ backgroundColor: red, boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)', borderRadius: '15px' }}>
          <Col md={6} className="text-center">
            <div className="mx-auto" style={{ width: "60%" }}>
              <Image src={data.url || defaultimg} style={{ borderRadius: "150px", width: "350px" }} className="d-block mx-auto" />
              <Button style={{ backgroundColor: button, marginTop: "10px" }} type="button" onClick={handleUploadClick} className="d-block mx-auto">
                Ganti Profile
              </Button>
            </div>
          </Col>

          <Col md={6}>
            <div style={{ backgroundColor: red, padding: '20px', boxShadow: boxShadow, borderRadius: borderRadius }}>
              {isEditMode ? (
              <><h1 className="text-white" style={{ fontWeight: "bold" }}>
                {data.name}
                </h1><hr style={{ height: "3px", backgroundColor: "black", border: "none" }} />
                                <Form className="text-white">
                                      <Row className="mb-3">
                                          <Form.Group as={Col} controlId="formNoHp">
                                              <Form.Label>Alamat Email</Form.Label>
                                              <Form.Control type="email" placeholder="Masukkan Alamat Email" value={data.email} readOnly />
                                          </Form.Group>
                                      </Row>

                                      <Row className="mb-3">
                                          <Form.Group as={Col} controlId="formJenisKelamin">
                                              <Form.Label>Jenis Kelamin</Form.Label>
                                              <Form.Control type="text" placeholder="Masukkan Jenis Kelamin" value={data.jk} readOnly />
                                          </Form.Group>
                                          <Form.Group as={Col} controlId="formNoTelp">
                                              <Form.Label>No Telp</Form.Label>
                                              <Form.Control type="tel" placeholder="Masukkan No Telp" value={data.no_telp} readOnly />
                                          </Form.Group>
                                      </Row>

                                      <Row className="mb-3">
                                          <Form.Group as={Col} controlId="formPesan">
                                              <Form.Label>Bio</Form.Label>
                                              <Form.Control as="textarea" rows={3} placeholder="Masukkan Pesan" value={data.bio} />
                                          </Form.Group>
                                      </Row>

                                      <Col className="text-end">
                                        <Button style={{ backgroundColor: red, marginRight: "10px", border: "none" }} type="button" onClick={(e) => { e.preventDefault(); handlePasswordClick(); }}>
                                            Ganti Kata Sandi
                                        </Button>
                                        <Button style={{ backgroundColor: button }} type="submit" onClick={handleSaveClick}>
                                            Edit
                                        </Button>
                                      </Col>
                                  </Form></>
              ) : (
                <><h1  className="text-white" style={{ fontWeight: "bold" }}>Edit Profile</h1><Form className="text-white">
                                      <Row className="mb-3">
                                          <Form.Group as={Col} controlId="formName">
                                              <Form.Label>Nama Lengkap</Form.Label>
                                              <Form.Control type="text" placeholder="Masukkan Alamat Nama" value={name} onChange={(e) => setName(e.target.value)} />
                                          </Form.Group>
                                      </Row>
                                      <Row className="mb-3">
                                          <Form.Group as={Col} controlId="formEmail">
                                              <Form.Label>Alamat Email</Form.Label>
                                              <Form.Control type="email" placeholder="Masukkan Alamat Email" value={email} onChange={(e) => setEmail(e.target.value)} />
                                          </Form.Group>
                                      </Row>

                                      <Row className="mb-3">
                                      <Form.Group as={Col} controlId="jenisKelamin">
                                          <Form.Label>Jenis Kelamin</Form.Label>
                                          <div style={{ display: 'flex', paddingLeft: '20px' }}>
                                            <Form.Check
                                              type="radio"
                                              label="male"
                                              name="jenisKelamin"
                                              id="male"
                                              style={{ paddingRight: '20px' }}
                                              checked={jk === 'male'}
                                              onChange={handleJenisKelaminChange}
                                            />
                                            <Form.Check
                                              type="radio"
                                              label="female"
                                              name="jenisKelamin"
                                              id="female"
                                              checked={jk === 'female'}
                                              onChange={handleJenisKelaminChange}
                                            />
                                          </div>
                                        </Form.Group>
                                          <Form.Group as={Col} controlId="formNoTelp">
                                              <Form.Label>No Telp</Form.Label>
                                              <Form.Control type="tel" placeholder="Masukkan No Telp" value={no_telp} onChange={(e) => setNoTelp(e.target.value)}  />
                                          </Form.Group>
                                      </Row>

                                      <Row className="mb-3">
                                          <Form.Group as={Col} controlId="formPesan">
                                              <Form.Label>Bio</Form.Label>
                                              <Form.Control as="textarea" rows={3} placeholder="Masukkan Pesan" value={bio} onChange={(e) => setBio(e.target.value)} />
                                          </Form.Group>
                                      </Row>

                                      <Col className="text-end">
                                        <Button style={{ backgroundColor: button, marginRight: "10px" }} type="button" onClick={handleEditClick}>
                                                Batal
                                          </Button>
                                          <Button style={{ backgroundColor: button, marginRight: "10px" }} type="button" onClick={handleSubmitData}>
                                              Save
                                          </Button>
                                      </Col>
                                  </Form></>
              )}
            </div>
          </Col>
        </Row>
      </Container>

      {/* Modal for Upload File */}
      <Modal show={showUploadModal} onHide={handleCloseUploadModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Upload File</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {/* Add your file upload form or component here */}
          <Form>
            <Form.Group controlId="formFile" className="mb-3">
              <Form.Label>Choose a file to upload</Form.Label>
              <Form.Control type="file" onChange={handleImageChange}  />
              {imagePreview && (
                <img
                  src={imagePreview}
                  alt="Image Preview"
                  className="mt-2 rounded-md h-14 w-20"
                  style={{ maxHeight: '200px' }}
                />
              )}
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseUploadModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSubmitProfile}>
            Upload
          </Button>
        </Modal.Footer>
      </Modal>


      {/* Change Password Modal */}
      <Modal show={showPasswordModal} onHide={handleClosePasswordModal} centered >
        <Modal.Header className="text-white" closeButton style={{ border: "none" , backgroundColor: red}}>
          <Modal.Title>Ganti Kata Sandi</Modal.Title>
        </Modal.Header>
        <Modal.Body  className="text-white" style={{ backgroundColor: red}}>
          {/* Add your change password form or component here */}
          {showAlert && (
                  <div className="flex items-center bg-red-200 text-white text-sm font-bold px-4 py-3" role="alert">
                    <p>{msg}</p>
                  </div>
                )}
          <Form>
            <Form.Group controlId="currentPassword" className="mb-3">
              <Form.Label>Kata Sandi Saat Ini</Form.Label>
              <Form.Control type="password" placeholder="Masukkan Kata Sandi Saat Ini" value={currentpassword} onChange={handleCurrentPassword} />
            </Form.Group>
            <Form.Group controlId="newPassword" className="mb-3">
              <Form.Label>Kata Sandi Baru</Form.Label>
              <Form.Control type="password" placeholder="Masukkan Kata Sandi Baru" value={password} onChange={handlePassword} />
            </Form.Group>
            <Form.Group controlId="confirmPassword" className="mb-3">
              <Form.Label>Konfirmasi Kata Sandi Baru</Form.Label>
              <Form.Control type="password" placeholder="Konfirmasi Kata Sandi Baru" value={cpassword} onChange={handleCpassword} />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer  className="text-white" style={{ backgroundColor: red, border: "none"}}>
          <Button variant="warning" onClick={handleClosePasswordModal}>
            Close
          </Button>
          <Button style={{
            backgroundColor: button
          }} onClick={handleSubmit}>
            Simpan
          </Button>
        </Modal.Footer>
      </Modal>

      <Footer />
    </div>
  );
};

export default Users;
