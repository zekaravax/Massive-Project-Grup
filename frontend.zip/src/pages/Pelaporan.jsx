import { Button, Col, Container, Form, Modal, Row } from "react-bootstrap";
import Footer from "../components/Footer";
import Headers from "../components/Headers";
import BreadcumbContentEdukasi from "../components/BreadcumbEdukasi";
import breadcumbImg from '../assets/pelaporan.svg';
import { useEffect, useState } from "react";
import useTokenRefresh from "../controllers/useToken";
import { PelaporanAllData } from "../controllers/PelaporanData";
import { Link } from "react-router-dom";
import axios from "axios";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShare, faEdit, faMessage, faStar, faCheck } from '@fortawesome/free-solid-svg-icons'

const red = '#BB2525';
const boxShadow = '0px 0px 10px rgba(0, 0, 0, 0.4)';
const borderRadius = '15px';
const button = '#2B2A4C';



const Pelaporan = () => {
  const [showAlert, setShowAlert] = useState(false);
  const [selectedName, setSelectedName] = useState(null);
  const [showNameList, setShowNameList] = useState(true);
  const { data, refreshToken, token } = useTokenRefresh();
  const { pelaporan } = PelaporanAllData();
  const [showForm, setShowForm] = useState(false); 
  const [showIcon, setShowIcon] = useState(true); 

  useEffect(() => {
    refreshToken();
  }, []);

  const handleTambahPengaduan = () => {
    setShowForm(true);
    setShowIcon(false)
  };

  const handleCloseAlert = () => {
    setShowAlert(false);
  };

  const handleNameClick = (id) => {
    const selectedPelaporan = pelaporan.find((data) => data.id === id);
    setSelectedName(selectedPelaporan);
    setShowNameList(false); // Hide the name list when a name is selected
  };

  const handleBack = () => {
    setShowNameList(true);
    setSelectedName(null);
  };

    const [nama, setNama] = useState("");
    const [kelas, setkelas] = useState("");
    const [jenkel, setjenkel] = useState("");
    const [tanggal_kejadian, settanggal_kejadian] = useState("");
    const [judul_laporan, setjudul_laporan] = useState("");
    const [isi_laporan, setisi_laporan] = useState("");
    const [jurusan, setjurusan] = useState("");
    const [email, setemail] = useState("");
    const [no_hp, setno_hp] = useState("");
    const [file, setFile] = useState(null);
    const [imagePreview, setImagePreview] = useState(null);

    const handleImageChange = (e) => {
      const image = e.target.files[0];
      setFile(image);

      const previewURL = URL.createObjectURL(image);
      setImagePreview(previewURL);
    };

    const handleNameChange = (e) => {
      setNama(e.target.value);
    };

    const handlejurusanchange = (e) => {
      setjurusan(e.target.value);
    };

    const handleemailchange = (e) => {
      setemail(e.target.value);
    };
  
    const handlekelasChange = (e) => {
      setkelas(e.target.value);
    };

    const handleJKChange = (value) => {
      if (jenkel === value) {
        setjenkel('');
      } else {
        setjenkel(value);
      }
    };

    const handleTanggalChange = (e) => {
      settanggal_kejadian(e.target.value);
    };

    const handlejudul_laporanChange = (e) => {
      setjudul_laporan(e.target.value);
    };

    const handleisi_laporaChange = (e) => {
      setisi_laporan(e.target.value);
    };

    const handleNoChange = (e) => {
      setno_hp(e.target.value);
    };
    
  
    const handleSubmit = async(e) => {
      e.preventDefault()
      const formData = new FormData()
      formData.append("name", nama)
      formData.append("kelas", kelas)
      formData.append("jenkel", jenkel)
      formData.append("tanggal_kejadian", tanggal_kejadian)
      formData.append("jurusan", jurusan)
      formData.append("email", email)
      formData.append("no_hp", no_hp)
      formData.append("judul_laporan", judul_laporan)
      formData.append("isi_laporan", isi_laporan)
      formData.append("file", file)
      try {
          const response = await axios.post("http://localhost:3000/savelapor", formData, {
              headers:{
                  "Authorization" : `Bearer ${token}`
              }
          })
          setShowAlert(true);
          // window.location.reload()
          console.log("sukses", response)
      } catch (error) {
          console.log(`error ni ${error}`)
      }
    };

    const handleok = () =>{
      window.location.reload()
    }

  return (
    <div className="overflow-x-hidden">
      <Headers />
      <BreadcumbContentEdukasi image={breadcumbImg} title="Pelaporan" sub1="Sekaranglah waktunya untuk melawan kekerasan dan bangkit mengatasinya." sub2="Karena kamu sangat berharga" />
      <Container className="my-5">
        <Row className="mt-5 p-4 justify-content-center">
          {showIcon && (
            <div
            style={{
              backgroundColor: red,
              padding: '20px',
              boxShadow: boxShadow,
              borderRadius: borderRadius,
              position: 'relative',
              height: "100px"
            }}
          >
          <div
            style={{
              position: 'absolute',
              top: '40%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              display: 'flex',
              flexDirection: 'row', // Set flexDirection to row
              alignItems: 'center',
            }}
          >
            <Col style={{ paddingTop: "2.5rem", color: "white"}}>
              <FontAwesomeIcon icon={faEdit} size="3x"  style={{ color: 'white', cursor: 'pointer' }} />
              <p>Laporan</p>
            </Col>
            <div
              style={{
                width: '2rem', // Adjust the width of the line
                height: '0', // Set height to 0 to make it a horizontal line
                borderBottom: '2px solid white', // Style the horizontal line
                margin: '0 2rem', // Adjust the spacing between icon and line
              }}
            />
            <Col style={{ paddingTop: "2.5rem", color: "white"}}>
              <FontAwesomeIcon icon={faShare} size="3x" style={{ color: 'white', cursor: 'pointer' }} />
              <p>Verifikasi</p>
            </Col>
            <div
              style={{
                width: '2rem',
                height: '0',
                borderBottom: '2px solid white',
                margin: '0 2rem',
              }}
            />
            <Col style={{ paddingTop: "2.5rem", color: "white"}}>
              <FontAwesomeIcon icon={faMessage} size="3x" style={{ color: 'white', cursor: 'pointer' }} />
              <p>Tindakan</p>
            </Col>            
            <div
              style={{
                width: '2rem',
                height: '0',
                borderBottom: '2px solid white',
                margin: '0 2rem',
              }}
            />
            <Col style={{ paddingTop: "2.5rem", color: "white"}}>
              <FontAwesomeIcon icon={faStar} size="3x" style={{ color: 'white', cursor: 'pointer' }} />
              <p>Feedback</p>
            </Col>
            <div
              style={{
                width: '2rem',
                height: '0',
                borderBottom: '2px solid white',
                margin: '0 2rem',
              }}
            />
            <Col style={{ paddingTop: "2.5rem", color: "white"}}>
              <FontAwesomeIcon icon={faCheck} size="3x" style={{ color: 'white', cursor: 'pointer' }} />
              <p>Selesai</p>
            </Col>
          </div>

          </div>
          )}
          
          <div
            style={{
              backgroundColor: red,
              padding: '20px',
              boxShadow: boxShadow,
              borderRadius: borderRadius,
              position: 'relative',
              marginTop: "5rem"
            }}
          >
            <Button
              style={{ backgroundColor: button, marginTop: '20px' }}
              onClick={handleTambahPengaduan}
              // The line above triggers the showForm state
            >
              Tambah Pengaduan
            </Button>

            {data.role === 'murid' && showForm && (
                <Form className="text-white">
                <Row className="mb-3">
                  <Form.Group as={Col} controlId="formNama">
                    <Form.Label>Nama</Form.Label>
                    <Form.Control type="text" placeholder="Masukkan Nama" value={nama} onChange={handleNameChange} />
                  </Form.Group>
                </Row>
  
                <Row className="mb-3">
                  <Form.Group as={Col} controlId="formKelas">
                    <Form.Label>Kelas</Form.Label>
                    <Form.Control type="text" placeholder="Masukkan Kelas" value={kelas} onChange={handlekelasChange} />
                  </Form.Group>
  
                  <Form.Group as={Col} controlId="formJenisKelamin">
                    <Form.Label>Jenis Kelamin</Form.Label>
                    <div style={{ display: 'flex', paddingLeft: "20px"}}>
                      <Form.Check
                        type="radio"
                        label="Laki-laki"
                        name="jenisKelamin"
                        id="laki-laki"
                        checked={jenkel === 'male'}
                        onChange={() => handleJKChange('male')}
                        style={{paddingRight: "20px"}}
                      />
                      <Form.Check
                        type="radio"
                        label="Perempuan"
                        name="jenisKelamin"
                        id="perempuan"
                        checked={jenkel === 'female'}
                        onChange={() => handleJKChange('female')}
                      />
                    </div>
                  </Form.Group>
                </Row>

                <Row className="mb-3">
                  <Form.Group as={Col} controlId="formJurusan">
                    <Form.Label>Jurusan</Form.Label>
                    <Form.Control type="text" rows={3} placeholder="Masukkan Jurusan" value={jurusan} onChange={handlejurusanchange} />
                  </Form.Group>
                  <Form.Group as={Col} controlId="formEmail">
                    <Form.Label>Email</Form.Label>
                    <Form.Control type="email" rows={3} placeholder="Masukkan Email" value={email} onChange={handleemailchange} />
                  </Form.Group>
                </Row>
  
                <Row className="mb-3">
                  <Form.Group as={Col} controlId="formTanggal">
                    <Form.Label>Tanggal</Form.Label>
                    <Form.Control type="date" rows={3} placeholder="Masukkan Tanggal" value={tanggal_kejadian} onChange={handleTanggalChange} />
                  </Form.Group>
                  <Form.Group as={Col} controlId="formPesan">
                    <Form.Label>No Hp</Form.Label>
                    <Form.Control type="tel" rows={3} placeholder="Masukkan No Hp" value={no_hp} onChange={handleNoChange} />
                  </Form.Group>
                </Row>
  
                <Row className="mb-3">
                  <Form.Group as={Col} controlId="formJudulLaporan">
                    <Form.Label>Judul Laporan</Form.Label>
                    <Form.Control type="text" placeholder="Masukkan Judul Laporan" value={judul_laporan} onChange={handlejudul_laporanChange} />
                  </Form.Group>
                </Row>
  
                <Row className="mb-3">
                  <Form.Group as={Col} controlId="formJudulLaporan">
                    <Form.Label>Ketik Laporan</Form.Label>
                    <Form.Control as="textarea" placeholder="Isi Laporan" value={isi_laporan} onChange={handleisi_laporaChange} />
                  </Form.Group>
                </Row>
  
                <Row className="mb-3">
                  <Form.Group as={Col} controlId="formJudulLaporan">
                    <Form.Control type="file" placeholder="Unggah Laporan" onChange={handleImageChange} />
                    {imagePreview && (
                    <img
                      src={imagePreview}
                      alt="Image Preview"
                      className="mt-2 rounded-md h-14 w-20"
                      style={{ maxHeight: '200px' }}
                    />
                  )}
                  </Form.Group>
                </Row>
  
                <Row className="mb-3">
                  <Col className="text-end">
                    <Button style={{ backgroundColor: button }} onClick={handleSubmit} type="submit">
                      Kirim Pesan
                    </Button>
                  </Col>
                </Row>
              </Form>
              )}

            {data.role === 'guru' && (
              <div>
              {showNameList &&
                pelaporan.map((data, index) => (
                  <div
                    key={index}
                    className="text-white"
                    style={{
                      padding: '10px',
                      margin: '5px',
                      boxShadow: boxShadow,
                      borderRadius: borderRadius,
                      cursor: 'pointer',
                    }}
                    onClick={() => handleNameClick(data.id)}
                    >
                    <p>{data.name}</p>
                  </div>
                ))}

              {selectedName && (
                <div className="text-white" style={{ padding: '20px', boxShadow: boxShadow, borderRadius: borderRadius }}>
                  <Form className="text-white">
                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formNama">
                        <Form.Label>Nama</Form.Label>
                        <Form.Control value={selectedName.name} readOnly/> 
                      </Form.Group>
                    </Row>

                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formKelas">
                        <Form.Label>Kelas </Form.Label>
                        <Form.Control value={selectedName.kelas} readOnly/> 
                      </Form.Group>
                    </Row>

                   <Row className="mb-3">
                      <Form.Group as={Col} controlId="formJenisKelamin">
                        <Form.Label>Jenis Kelamin </Form.Label>
                        <Form.Control value={selectedName.jenkel} readOnly/> 
                      </Form.Group>
                    </Row>

                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formTanggal">
                        <Form.Label>Tanggal </Form.Label>
                        <Form.Control value={selectedName.tanggal_kejadian} readOnly/> 
                      </Form.Group>
                    </Row>

                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formPesan">
                        <Form.Label>No Hp </Form.Label>
                        <Form.Control value={selectedName.no_hp} readOnly/> 
                      </Form.Group>
                    </Row>

                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formJudulLaporan">
                        <Form.Label>Judul Laporan </Form.Label>
                        <Form.Control value={selectedName.judul_laporan} readOnly/> 
                      </Form.Group>
                    </Row>

                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formJudulLaporan">
                        <Form.Label>Ketik Laporan </Form.Label>
                        <Form.Control as="textarea" value={selectedName.isi_laporan} readOnly/> 
                      </Form.Group>
                    </Row>

                    <Row className="mb-3">
                      <Form.Group as={Col} controlId="formJudulLaporan">
                            <img
                              src={selectedName.url}
                              alt="Image Preview"
                              className="mt-2 rounded-md h-14 w-20"
                              style={{ maxHeight: '200px' }}
                            />                      
                            </Form.Group>
                    </Row>

                    <Row className="mb-3">
                      <Col className="text-start">
                        <Button style={{ backgroundColor: button }} onClick={handleBack} type="submit">
                          Kembali
                        </Button>
                      </Col>
                    </Row>
                  </Form>
                </div>
              )}
            </div>
            )}
        </div>
      </Row>

    </Container>
    <Footer />

      {/* Modal for Alert */}
      <Modal show={showAlert} onHide={handleCloseAlert} className="bg-transparent">
        <Modal.Body className='text-center'>
          <div className=' flex items-center justify-center rounded-t-3xl' style={{ height: '100px' }}>
            <img src={"alertImg"} alt="" className='h-24' />
          </div>
          <div className='flex-1 bg-white flex flex-col justify-center rounded-b-3xl h-full' style={{ height: '400px' }}>
            <p className='font-bold text-2xl mb-4 mt-20' style={{ color: "#211F54", fontWeight:"bold", fontSize: "3rem" }}>Your Report Has Been Submitted</p>
            <Link to={'#'}>
              <Button
                size="sm"
                variant='danger'
                onClick={handleok}
                className="text-white text-center rounded-full mb-10 w-28 font-bold text-[14px] h-12 hover:text-red-400 hover:bg-white"
              >
                View Status
              </Button>
            </Link>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default Pelaporan;