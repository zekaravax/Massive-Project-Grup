import { Button,  Card,  Col,  Container,  Image,  Row } from "react-bootstrap";
import Footer from "../components/Footer";
import Headers from "../components/Headers";
import BreadcumbContentEdukasi from "../components/BreadcumbEdukasi";
import breadcumbImg from '../assets/pelaporan.svg';
import { useEffect, useState } from "react";
import useTokenRefresh from "../controllers/useToken";
import axios from "axios";
import ChatBox from "./sample";
import { io } from "socket.io-client";
import ks from '../assets/ks.png'
const red = '#BB2525';
const boxShadow = '0px 0px 10px rgba(0, 0, 0, 0.4)';
const borderRadius = '15px';
const button = '#2B2A4C';
const socket = io.connect("http://localhost:3000")


const Konsultasi = () => {
  const [selectedName, setSelectedName] = useState(null);
  const [showNameList, setShowNameList] = useState(true);
  const { data, refreshToken } = useTokenRefresh();
  const [datares, setData] = useState([])
  const [showChat, setShowChat] = useState(false);

  const [username, setUsername] = useState("");
  const [userId, setUserId] = useState("");
  const [room, setRoom] = useState("");

  const getMe = async() => {
    const response = await axios.get(`http://localhost:3000/me`)
    setUserId(response.data.id)
    setUsername(response.data.name)
    setRoom(response.data.room)
    console.log("dataresp", response.data.name)
  };
  useEffect(() => {
    getMe();
  }, [])

  useEffect(() => {
    refreshToken();
    getusersmsg();
  }, []);

  const getusersmsg = async () => {
    try {
      const response = await axios.get(`http://localhost:3000/getusersmessage`);
      console.log("Data Response Message:", response.data);
      setData(response.data)
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const updateDataGuru = async ( room) => {
    try {
      const response = await axios.patch('http://localhost:3000/updateroom', { room });
      console.log('Data Response:', response.data);
      setData(response.data);
    } catch (error) {
      console.error('Error updating room:', error);
    }
  };

  const handleNameClick = (id, room) => {
    const selectedRes = datares.find((data) => data.id === id);
    setSelectedName(selectedRes);
  
    // // Call the function to update the room
    updateDataGuru(room);
    setRoom(room)
  
    setShowNameList(false);
  };

  const joinRoom = () => {
    if (username !== "" && room !== "") {
      socket.emit("join_room", room);
      setShowChat(true);
    }

    console.log(username, room, "dataroomnih")
  };

  const handleBack = () => {
    window.location.reload()
  };

  return (
    <div className="overflow-x-hidden">
      <Headers />
      <BreadcumbContentEdukasi image={breadcumbImg} title="Pelaporan" sub1="Sekaranglah waktunya untuk melawan kekerasan dan bangkit mengatasinya." sub2="Karena kamu sangat berharga" />
      <Container className="my-5">
        <Row className="mt-5 p-4 justify-content-center">
             
            {data.role === 'murid' && (
                <>
                {!showChat ? (
                    <div >
                      <h1>Apa Itu Layanan Konsultasi</h1>
                      <Col >
                        <Card style={{ marginBottom: '15px', borderRadius: '15px', display: 'flex', flexDirection: 'row' }}>
                          <Card.Header style={{ flex: '1' }}>
                            <Image src={ks} style={{ width: '100%', objectFit: 'cover' }} />
                          </Card.Header>
                          <div className="border-top border-white"></div>
                          <Card.Body style={{ flex: '2' }}>
                            <p>Layanan kami ini fokus membantu korban kekerasan dalam pengobatan dan pencegahan gangguan kejiwaan seperti gangguan mental, emosional, dan perilaku. Guru BK akan membantu dan melakukan sebagai penanganan seperti memberikan penanganan awal bagi korban penindasan di sekolah sesuai dengan kebutuhan masing-masing korban.</p>
                          </Card.Body>
                        </Card>
                      </Col>

                    <Button style={{ backgroundColor: button}} onClick={joinRoom}> Konsultasi </Button>
                    </div>
                ) : (
                  <div className="text-white" style={{ padding: '20px', boxShadow: boxShadow, borderRadius: borderRadius }}>
                  <ChatBox socket={socket} username={username} room={room} userId={userId} />
                  <Button style={{ backgroundColor: red }} onClick={handleBack} > Kembali </Button>
                </div>
                )}
                
                </>
              )}
              {data.role === 'guru' && (
          <div
            style={{
              backgroundColor: red,
              padding: '20px',
              boxShadow: boxShadow,
              borderRadius: borderRadius,
              position: 'relative',
              marginTop: "5rem"
            }}
          >
          
            <div>
              {showNameList &&
                (Array.isArray(datares) ? (
                  datares.map((data, index) => (
                    <div
                      key={index}
                      className="text-white"
                      style={{
                        padding: '10px',
                        margin: '5px',
                        boxShadow: boxShadow,
                        borderRadius: borderRadius,
                        cursor: 'pointer',
                      }}
                      onClick={() => handleNameClick(data.id, data.room)}
                    >
                      <p>{data.name}</p>
                    </div>
                  ))
                ) : (
                  <p>Loading...</p>
                ))}

              {selectedName && (
                <div className="text-white" style={{ padding: '20px', boxShadow: boxShadow, borderRadius: borderRadius }}>
                  <ChatBox socket={socket} username={username} room={room} userId={userId} />
                  <Button style={{ backgroundColor: red }} onClick={handleBack} > Kembali </Button>
                </div>
              )}
            </div>

        </div>
          )}
      </Row>

    </Container>
    <Footer />

    
    </div>
  );
};

export default Konsultasi;