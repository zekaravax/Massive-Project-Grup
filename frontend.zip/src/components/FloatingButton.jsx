import { Button } from 'react-bootstrap';

const red = '#BB2525';

const FloatingButton = ({ onClick }) => {
  return (
    <Button
      style={{
        backgroundColor: red
      }}
      onClick={onClick}
    >
      <p className="font-bold text-xl">+</p>
    </Button>
  );
};

export default FloatingButton;
