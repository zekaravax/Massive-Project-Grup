import React from 'react';
import { Button, Modal } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css'; // Make sure to include the Bootstrap CSS

import { Link } from 'react-router-dom';

const CustomDialog = () => {
  const [show, setShow] = React.useState(false);

  const handleOpen = () => setShow(true);
  const handleClose = () => setShow(false);

  return (
    <>
      <Button variant='danger' size="sm" title="test" onClick={handleOpen}></Button>
      <Modal show={show} onHide={handleClose} className="bg-transparent">
        <Modal.Header closeButton>
          <Modal.Title className='text-black mx-auto font-extrabold'>Your Title Here</Modal.Title>
        </Modal.Header>
        <Modal.Body className='text-center'>
          <div className='bg-red-300 h-full flex items-center justify-center rounded-t-3xl' style={{ height: '200px' }}>
            <img src={"alertImg"} alt="" className='h-24' />
          </div>
          <div className='flex-1 bg-white flex flex-col justify-center rounded-b-3xl h-full' style={{ height: '400px' }}>
            <p className='font-bold text-2xl mb-4 mt-20'>PERINGATAN!!</p>
            <p className='text-lg mb-8'>Anda belum memiliki akun</p>
            <Link to={'/login'}>
              <Button
                size="sm"
                variant='danger'
                onClick={handleClose}
                className="text-white text-center rounded-full mb-10 w-28 font-bold text-[14px] h-12 hover:text-red-400 hover:bg-white"
              >
                Login
              </Button>
            </Link>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default CustomDialog;
