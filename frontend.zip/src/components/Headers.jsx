import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Navbar, Nav, Button } from 'react-bootstrap';
import useTokenRefresh from '../controllers/useToken';
import FunctionLogout from '../controllers/Logout';
import imagedefault from '../assets/default.png';

const Headers = () => {
  const location = useLocation();
  const [activePath] = useState(location.pathname);
  const { data,  refreshToken } = useTokenRefresh()
  const { Logout } = FunctionLogout()


  useEffect(() => {
    refreshToken();
  }, [])

  return (
    <Navbar expand="lg" variant="dark" style={{ backgroundColor: "#2B2A4C" }}>
      <div className='container'>
      <Navbar.Brand as={Link} to="/" style={{ fontWeight: "bold" }}>
        Abuse
        <div className='ml-4' style={{ marginLeft: "2rem" }}>Shield</div>
      </Navbar.Brand>

      <Navbar.Toggle aria-controls="navbarNav" />

      <Navbar.Collapse id="navbarNav">
        <div className=" navbar-collapse justify-content-end" >
          <Nav className="mr-auto">
            <Nav.Link as={Link} to="/" className={activePath === '/' ? 'active' : ''}>
              Beranda
            </Nav.Link>
            <Nav.Link as={Link} to="/" className={activePath === '/tentang' ? 'active' : ''}>
              Tentang
            </Nav.Link>
            <Nav.Link as={Link} to="/" className={activePath === '/melayani' ? 'active' : ''}>
              Melayani
            </Nav.Link>
            <Nav.Link as={Link} to="/" className={activePath === '/FAQ' ? 'active' : ''}>
              FAQ
            </Nav.Link>
            <Nav.Link as={Link} to="/" className={activePath === '/kontak' ? 'active' : ''}>
              Kontak
            </Nav.Link>
          </Nav>
          <Nav>
          {data.userId ? (
            <Nav.Link as={Link} to="/users">
              <img src={imagedefault} alt="Avatar" className="avatar" width="40px" height="40px" />
            </Nav.Link>
          ) : (
            <Nav.Link as={Link} to="/login" className={window.location.pathname === '/' ? 'active' : ''}>
              <Button variant="danger">
                Login
              </Button>
            </Nav.Link>
          )}
          {data.userId && (
            <Button variant="secondary" onClick={Logout}>
              Logout
            </Button>
          )}
          </Nav>
      </div>
      </Navbar.Collapse>
      </div>
    </Navbar>
  );
};

export default Headers;
