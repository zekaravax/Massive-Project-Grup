import React from 'react';
import { Modal, Button, Form, Col, Row } from 'react-bootstrap';
import { EdukasiAddData } from '../controllers/EdukasiData';

const PopupFormEdukasi = ({ isVisible, onClose }) => {
  const {
    title,
    content,
    imagePreview,
    handleContentChange,
    handleImageChange,
    handleTitleChange,
    handleSubmit
  } = EdukasiAddData();
  

  return (
    <Modal show={isVisible} onHide={onClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Tambah Edukasi</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group as={Row} controlId="title">
            <Form.Label column sm={3}>
              Judul Edukasi
            </Form.Label>
            <Col sm={9}>
              <Form.Control
                type="text"
                value={title}
                onChange={handleTitleChange}
                required
              />
            </Col>
          </Form.Group>

          <Form.Group as={Row} controlId="content">
            <Form.Label column sm={3}>
              Isi Edukasi
            </Form.Label>
            <Col sm={9}>
              <Form.Control
                as="textarea"
                rows={5}
                value={content}
                onChange={handleContentChange}
              />
            </Col>
          </Form.Group>

          <Form.Group as={Row} controlId="file">
            <Form.Label column sm={3}>
              Masukkan Foto
            </Form.Label>
            <Col sm={9}>
              <Form.Control
              type="file"
                id="file"
                label="Choose file"
                onChange={handleImageChange}
              />
              {imagePreview && (
                <img
                  src={imagePreview}
                  alt="Image Preview"
                  className="mt-2 rounded-md h-14 w-20"
                  style={{ maxHeight: '200px' }}
                />
              )}
            </Col>
          </Form.Group>

          <Button
            variant="danger"
            type="submit"
            onClick={handleSubmit}
            className="mt-3"
          >
            Kirim
          </Button>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default PopupFormEdukasi;
