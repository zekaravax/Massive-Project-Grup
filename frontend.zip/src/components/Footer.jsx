import { Row } from "react-bootstrap";


const Footer = () => {
  return (
    <div className="text-white container-fluid" style={{ backgroundColor: ' rgb(23, 27, 20)'}}>
        <Row style={{
            backgroundColor: "#2B2A4C",
            padding: "2rem",
            
        }}>
          <p>Copyright © 2025 Abuseshield.org | All Rights Reserved</p>
        </Row>
    </div>
  );
};

export default Footer;
