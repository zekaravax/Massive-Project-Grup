import { useEffect } from 'react';
import { Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

import breadcumbImg from '../assets/bg.svg';
import useTokenRefresh from '../controllers/useToken';

const BreadcumbContent = () => {
  const navigate = useNavigate()
  const { data,  refreshToken } = useTokenRefresh()

  useEffect(() => {
    refreshToken();
  }, [])

  const handleMulai = () => {
    navigate('/login')
  }

  return (
    <div className="container-fluid">
      <div className="row justify-content-center align-items-center position-relative">
        <div
          className="text-center position-relative z-index-1"
          style={{
            backgroundImage: `url(${breadcumbImg})`,
            height: '600px', // Set the height to match your image height
            width: '100%', // Make it full-width
            backgroundSize: 'cover', // Optional: Adjust the background size
            position: 'relative',
          }}
        >
          {/* Yellow overlay with reduced opacity */}
          <div
            className='bg-white'
            style={{
              height: '100%',
              width: '100%',
              backgroundSize: 'cover',
              position: 'absolute',
              top: 0,
              left: 0,
              opacity: 0.5, // Adjust the opacity as needed
            }}
          ></div>
        </div>

        <div className="col d-flex flex-column justify-content-center align-items-center custom-mt-7"
          style={{
            marginTop: '5rem',
            position: 'absolute',
            zIndex: 2, // Ensure text is on top of the overlay
            color: 'red', // Set text color
          }}
        >
          <h2 style={{
            fontWeight: 'normal',
            
          }}>
            Sekaranglah waktunya untuk melawan kekerasan dan bangkit mengatasinya.
          </h2>
          <h2 className="font-bold pt-3 pb-3">
            Karena kamu sangat berharga
          </h2>
          {data.userId ? (
          <p></p>
          ) : (
          <Button variant="danger" className="mx-auto d-block" onClick={handleMulai}>
            Memulai
          </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default BreadcumbContent;
