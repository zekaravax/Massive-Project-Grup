import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export const LoginAction = () => {
    const navigate = useNavigate();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [userrole, setRole] = useState('');
    const [msg, setMsg] = useState('')

    const handleUsername = (e) => {
        setUsername(e.target.value);
    }

    const handlePassword = (e) => {
        setPassword(e.target.value)
    }

    const handleLoginGuru = async (e) => {
        e.preventDefault();
        try {
        const response = await axios.post('http://localhost:3000/login', {
            username: username,
            password: password
        });
    
        setRole(response.data.role)
        if (response.data.role.toLowerCase() === "guru") {
            navigate('/');
        } 
         else {
            setMsg("Anda Bukan Guru");
        }
        } catch (error) {
        if (error.response) {
            console.log('Error Response:', error.response.data);
            setMsg(error.response.data.msg);
        }
        }
    };

    const handleLoginMurid = async (e) => {
        e.preventDefault();
        try {
        const response = await axios.post('http://localhost:3000/login', {
            username: username,
            password: password
        });
    
        setRole(response.data.role)
        if (response.data.role.toLowerCase() === "murid") {
            navigate('/');
        } else {
            setMsg("Username Tidak Ditemukan");
        }
        console.log("response", response.data.role)
        } catch (error) {
        if (error.response) {
            console.log('Error Response:', error.response.data);
            setMsg(error.response.data.msg);
        }
        }
    };

    return { username, password, userrole, msg, handleLoginGuru,handleLoginMurid, handleUsername, handlePassword}
}
