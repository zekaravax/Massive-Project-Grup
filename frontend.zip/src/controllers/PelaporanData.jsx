import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import axios from "axios";
import { useEffect, useState } from "react";
import useTokenRefresh from "./useToken";

export const PelaporanAllData = () => {
    const [pelaporan, setPelaporan] = useState([]);
    const { token, axiosJWT, refreshToken} = useTokenRefresh()
  
    useEffect(() => {
      getPelaporan();
      refreshToken();
    }, []); 
  
    const getPelaporan = async () => {
      try {
        const response = await axios.get("http://localhost:3000/lapor");
        setPelaporan(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    const handleDelete = async(Pelaporanid) => {
      try {
          await axiosJWT.delete(`http://localhost:3000/deletelapor/${Pelaporanid}`, {
              headers:{
                  "Authorization" : `Bearer ${token}`
              }
          })
          getPelaporan()
      } catch (error) {
          console.log(error)
      }
    }

    const countTotalData = () => {
      return pelaporan.length;
    };
  
      let counterid = 1;
      const datatabel = pelaporan.map((item) => {
        return {
            id: counterid++,
            nama: item.nama,
            kelas: item.kelas,
            jenkel: item.jenkel,
            jurusan: item.jurusan,
            email: item.email,
            tanggal_kejadian: item.tanggal_kejadian,
            no_hp: item.no_hp,
            judul_laporan: item.judul_laporan,
            isi_laporan: item.isi_laporan,
            reshus: item.reshus,
            action: "",
            item_id: item.id,
            }
        });
  
      const columns = [
      { name: "ID", selector: "id", sortable: true },
      { name: "Nama", selector: "nama", sortable: true },
      { name: "Kelas", selector: "kelas", sortable: true },
      { name: "jenkel", selector: "jenkel", sortable: true },
      { name: "Jurusan", selector: "jurusan", sortable: true },
      { name: "Email", selector: "email", sortable: true },
      { name: "Tanggal Kejadian", selector: "tanggal_kejadian", sortable: true },
      { name: "Judul Laporan", selector: "judul_laporan", sortable: true },
      { name: "Isi Laporan", selector: "isi_laporan", sortable: true },
      { name: "no_hp", selector: "no_hp", sortable: true },

      {
          name: "Action",
          selector: "action",
          sortable: true,
          cell: (row) => (
          <div>
              <FontAwesomeIcon icon={faTrash} onClick={() => handleDelete(row.item_id)} style={{ cursor: "pointer", marginRight: "10px" }} />
          </div>
          ),
      },
      ];
  
      return {
        pelaporan,
          handleDelete,
          datatabel,
          columns,
          getPelaporan,
          countTotalData
      }
  }

  export const PelaporanDetail = (id) => {
    const { refreshToken } = useTokenRefresh();
    const [pelaporanDetail, setPelaporanDetail] = useState(null);
  
    useEffect(() => {
      getPelaporanById();
      refreshToken();
    }, [id]);
  
    const getPelaporanById = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/deletelapor/${id}`);
        setPelaporanDetail(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
  
    return {
      pelaporanDetail,
      getPelaporanById,
    };
  };