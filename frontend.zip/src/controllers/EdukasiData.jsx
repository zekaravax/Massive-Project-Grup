import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import axios from "axios";
import { useEffect, useState } from "react";
import useTokenRefresh from "./useToken";

export const EdukasiAllData = () => {
    const [edukasi, setEdukasi] = useState([]);
    const { token, refreshToken} = useTokenRefresh()
  
    useEffect(() => {
      getEdukasi();
      refreshToken()
    }, []); 
  
    const getEdukasi = async () => {
      try {
        const response = await axios.get("http://localhost:3000/edukasi");
        setEdukasi(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
  
    const handleDelete = async(Edukasiid) => {
      try {
          await axios.delete(`http://localhost:3000/deleteedukasi/${Edukasiid}`, {
              headers:{
                  "Content-Type": "multipart/form-data",
                  "Authorization" : `Bearer ${token}`
              }
          })
          getEdukasi()
      } catch (error) {
          console.log(error)
      }
    }
  
    const EdukasiData = () => {
      return edukasi.length;
    };

    let counterid = 1;
    const sortedEdukasi = edukasi.sort((a, b) => {
      const dateA = new Date(a.dibuat_pada);
      const dateB = new Date(b.dibuat_pada);
      return dateB - dateA; 
    });
  
    const datatabel = sortedEdukasi.map((item) => {
      return {
        id: counterid++,
        title: item.judul,
        content: item.content,
        image: item.url,
        action: "",
        item_id: item.id,
      };
    });
  
      const columns = [
      { name: "ID", selector: "id", sortable: true, minWidth: "20%" },
      { name: "Judul", selector: "title", sortable: true },
      {
          name: "Image",
          selector: "image",
          sortable: true,
          cell: (row) => <img src={row.image} alt="Article" style={{ width: "50px", height: "50px" }} />,
      },
      {
          name: "Action",
          selector: "action",
          sortable: true,
          cell: (row) => (
          <div>
              <FontAwesomeIcon icon={faTrash} onClick={() => handleDelete(row.item_id)} style={{ cursor: "pointer", marginRight: "10px" }} />
          </div>
          ),
      },
      ];
  
      return {
          edukasi,
          handleDelete,
          datatabel,
          columns,
          getEdukasi,
          EdukasiData
      }
  }

export const EdukasiAddData = () => {
    const [title, setTitle] = useState("");
    const [content, setContent] = useState("");
    const [file, setFile] = useState(null);
    const [imagePreview, setImagePreview] = useState(null);
    const { token, refreshToken} = useTokenRefresh()

    useEffect(() => {
      refreshToken();
    }, []);

    const handleTitleChange = (e) => {
      setTitle(e.target.value);
    };
  
    const handleContentChange = (e) => {
      setContent(e.target.value);
    };

    const handleImageChange = (e) => {
      const image = e.target.files[0];
      setFile(image);

      const previewURL = URL.createObjectURL(image);
      setImagePreview(previewURL);
    };

  
    const handleSubmit = async(e) => {
      e.preventDefault()
      const formData = new FormData()
      formData.append("file", file)
      formData.append("judul", title)
      formData.append("content", content)
      try {
          const response = await axios.post("http://localhost:3000/saveedukasi", formData, {
              headers:{
                  "Content-Type": "multipart/form-data",
                  "Authorization" : `Bearer ${token}`
              }
          })
          window.location.reload();
          console.log("sukses", response)
      } catch (error) {
          console.log("error", error, token)
      }
    };


  return { title, content, file, imagePreview, handleContentChange, handleImageChange, handleTitleChange, handleSubmit };
};


