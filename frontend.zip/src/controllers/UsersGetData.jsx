import useTokenRefresh from "./useToken";
import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

// export const UsersGetData = () => {
//   const [users, setUsers] = useState([]);
//   const { refreshToken, token} = useTokenRefresh()

//   useEffect(() => {
//     getUsers();
//     refreshToken();
//   }, [])

//   const getUsers = async () => {
//     try {
//       const response = await axios.get("https://upset-polo-shirt-ray.cyclic.app/users", {
//         headers: {
//           Authorization: `Bearer ${token}`
//         }
//       });
//       setUsers(response.data);
//     } catch (error) {
//       console.error("Error fetching data:", error);
//     }
//   }

//   let counterid = 1;
//     const dataTabeluser = users.map((item) => ({
//     id: counterid++,
//     name: item.name,
//     username: item.username,
//     noTelp: item.no_telp,
//     jk: item.jk,
//     alamat: item.alamat,
//     image: item.url,
//     action: "",
//     }));

//     const columns = [
//     { name: "ID", selector: "id", sortable: true },
//     { name: "Nama Lengkap", selector: "name", sortable: true },
//     { name: "Username", selector: "username", sortable: true },
//     { name: "NO Telepon", selector: "noTelp", sortable: true },
//     { name: "Jenis Kelamin", selector: "jk", sortable: true },
//     { name: "Alamat", selector: "alamat", sortable: true },
//     {
//         name: "Image",
//         selector: "image",
//         sortable: true,
//         cell: (row) => <img src={row.image} alt="Article" style={{ width: "50px", height: "50px" }} />,
//     },
//     ];


//   return { getUsers, users, columns, dataTabeluser };
// };

export const UsersGetDataWithID = () => {
  const [usersData, setData] = useState([]);
  const { refreshToken, dataId} = useTokenRefresh()
  const [datarole, setdatarole] = useState('')

  useEffect(() => {
    getUsersWithID();
  }, []); 

  const getUsersWithID = async () => { 
    try {
      const response = await axios.get(`http://localhost:3000/me/${dataId.userId}`);
      setData(response.data);
      setdatarole(response.data.role);
    } catch (error) {
      console.log("Error fetching data:", error);
      console.log("userid", dataId.userId);
    }
  }


  return { getUsersWithID, usersData, datarole };
};



export const UsersReset = () => {
  const { refreshToken } = useTokenRefresh(); // Pastikan bahwa useTokenRefresh mengembalikan refreshToken
  const [password, setPassword] = useState('');
  const [cpassword, setCpassword] = useState('');
  const [currentpassword, setCurrentPassword] = useState('');
  const [msg, setMsg] = useState('')

  useEffect(() => {
    refreshToken();
  }, [refreshToken]); // Ubah dependencies useEffect sesuai kebutuhan

  const handlePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleCpassword = (e) => {
    setCpassword(e.target.value);
  };

  const handleCurrentPassword = (e) => {
    setCurrentPassword(e.target.value);
  };

  const handleSubmit = async () => {
    try {
      if (password !== cpassword) {
        setMsg('Password and Confirm Password do not match');
        return;
      }

      // Gantilah URL sesuai dengan endpoint update password di backend Anda
      const apiUrl = 'http://localhost:3000/updatepassword';

      const formData = {
        currentPassword: currentpassword,
        newPassword: password,
        confirmPassword: cpassword,
      };

      await axios.post(apiUrl, formData);

      await axios.delete('http://localhost:3000/logout');
      window.location.reload();
    } catch (error) {
      console.error('Error updating password:', error);
      setMsg(error.response.data.msg);
    }
  };

  return { handlePassword,msg, password, handleSubmit, cpassword, handleCpassword, currentpassword, handleCurrentPassword };
};


export const UsersEditData = () => {
  const [file, setFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const navigate = useNavigate();
  const { token, refreshToken } = useTokenRefresh();

  const handleImageChange = (e) => {
    const image = e.target.files[0];
    setFile(image);

    const previewURL = URL.createObjectURL(image);
    setImagePreview(previewURL);
  };

  const handleSubmitProfile = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await axios.post(`http://localhost:3000/updateprofile`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          "Authorization": `Bearer ${token}`
        },
      });

      console.log("sukses", response);
      window.location.reload()
    } catch (error) {
      console.error("error", error);
    }
  };

  useEffect(() => {
    refreshToken();
  }, [refreshToken]);

  return {
    imagePreview,
    handleImageChange,
    handleSubmitProfile,
  };
};